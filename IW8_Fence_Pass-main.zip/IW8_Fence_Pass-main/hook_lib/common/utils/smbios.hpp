#pragma once

#include <string>

namespace utils::smbios
{
	std::string get_uuid();
}
